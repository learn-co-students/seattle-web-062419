require 'pry'

require './lib/person'
require './lib/business'